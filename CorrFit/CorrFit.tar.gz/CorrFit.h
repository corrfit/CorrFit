#ifndef _CORRFIT_H_
#define _CORRFIT_H_

#include "PairReader.h"

#endif
