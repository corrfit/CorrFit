#include "SourceModel.h"

SourceModel::SourceModel()
{
}

SourceModel::~SourceModel()
{
}

int
SourceModel::GetNParameters()
{
  return mNPar;
}

int         
SourceModel::GetNRandVar()
{
  return mNRandVar;
}

