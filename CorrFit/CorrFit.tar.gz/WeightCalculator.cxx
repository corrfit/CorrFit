
#include "WeightCalculator.h"

inline int  WeightCalculator::getPairType() { 
  return mLL; 
}

WeightCalculator::WeightCalculator()
{

}


